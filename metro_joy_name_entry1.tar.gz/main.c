
// Metro-Cross.
// Code: Clement '17o2!!' CORDE
// Contact: Clement CORDE, c1702@yahoo.com

// Using :
// ST-Sound by Leonard/OXG.
// Atari ST Musics and 8x8 font.
// Arcade graphics.


#define	EMERGENCY_EXIT	(1)	// Sortie du jeu avec Esc.

#include "includes.h"
#include "sprites_inc.h"


// Variables générales.
struct SGene gVar;

//=============================================================================

/*
#if defined(__LINUX__) || defined(__APPLE__)
#include <strings.h>
// stricmp n'existe pas en Linux : C'est strcasecmp à la place, dans strings.h.
int stricmp(char *pStr1, char *pStr2)
{
	return (strcasecmp(pStr1, pStr2));
}
#endif
*/

//=============================================================================

struct SCheatCodes	gCCodes;

// Cheat codes - Reset de la saisie.
void CheatCodes_Reset(void)
{
	gCCodes.nIdx = 0;
	gCCodes.nCnt = 0;
	gCCodes.nEnter = 0;
}

// Cheat codes - Compteur.
void CheatCodes_Counter(void)
{
	if (gCCodes.nCnt == 0) return;
	if (--gCCodes.nCnt == 0) CheatCodes_Reset();
}

// Les codes en version non lisible avec un éditeur hexa. (Chr majuscules : 0x40 > 0x5F).
u8 gpCodes[CHEATCODES_NB][CHEATCODES_TBSZMAX + 1] =
{
	{ 'L' ^ 0x1F, 'E' ^ 0x2E, 'V' ^ 0x3D, 'E' ^ 0x0C, 'L' ^ 0x1B, 'S' ^ 0x2A, 0, 0, 0, 0, 0 },				// Level select.
	{ 'N' ^ 0x1F, 'O' ^ 0x2E, 'T' ^ 0x3D, 'I' ^ 0x0C, 'M' ^ 0x1B, 'E' ^ 0x2A, 0, 0, 0, 0, 0 },				// Unlimited time.
};
u8 gpCodesOR[CHEATCODES_NB] =
	{ e_Cheat_LevelSelect, e_Cheat_UnlimitedTime };

// Cheat codes - Touche pressée.
void CheatCodes_KeyPressed(u32 nSdlKey)
{
	// On est en mode entrée de cheat ?
	if (gCCodes.nEnter == 0)
	{	// Non. On y passe ?
		if (nSdlKey == SDLK_F5) gCCodes.nEnter = 1;
		return;
	}
	gVar.pKeys[nSdlKey] = 0;	// RAZ touche.

	// Appui.
	if (gCCodes.nIdx >= CHEATCODES_TBSZMAX - 1) return;
	if (nSdlKey < SDLK_a || nSdlKey > SDLK_z) return;
	nSdlKey -= SDLK_a;
	nSdlKey += 'A';
	nSdlKey ^= (((gCCodes.nIdx + 1) * 0x10) & 0x30) | (0x0F - gCCodes.nIdx);	// On code ici comme le cheat la lettre entrée.
	gCCodes.pTb[gCCodes.nIdx++] = (char)nSdlKey;
	gCCodes.pTb[gCCodes.nIdx] = 0;		// Arrête la chaîne au suivant.
	gCCodes.nCnt = CHEATCODES_TIMER;	// Timer.

	// Test du code.
	u32	i;
	for (i = 0; i < CHEATCODES_NB; i++)
	{
		if (memcmp(gCCodes.pTb, &gpCodes[i][0], strlen((char *)&gpCodes[i][0])) == 0)
		{
			gCCodes.nCheat ^= gpCodesOR[i];
			CheatCodes_Reset();
			Sfx_PlaySfx(e_Sfx_Cracker, e_SfxPrio_0);	// Sfx.
			return;
		}
	}

}

// Affichage des cheat codes (sur la page principale).
void CheatCodes_Display(void)
{
	char	*ppTxt[CHEATCODES_NB] = { "LVL", "TIM" };
	char	pStr[((CHEATCODES_NB + 1) * 4) + 1];	// (CHEATCODES_NB + 1) pour l'affichage du numéro du level.
	u32	nIdx = 0;
	u32	i;

	if (gCCodes.nCheat == 0) return;

	pStr[nIdx] = 0;
	for (i = 0; i < CHEATCODES_NB; i++)
	{
		if (gCCodes.nCheat & (1 << i))
		{
			// On copie le code du cheat sur 3 lettres.
			if (nIdx) pStr[nIdx++] = '-';
			pStr[nIdx] = *(ppTxt[i]);
			pStr[nIdx+1] = *(ppTxt[i] + 1);
			pStr[nIdx+2] = *(ppTxt[i] + 2);
			nIdx += 3;
			pStr[nIdx] = 0;
			// Cas spécial du choix du level qu'on ajoute au cul de LVL : "LVL(xx)".
			if (i == 0)
			{
				pStr[nIdx] = '(';
				snprintf(&pStr[nIdx+1], 3, "%02d", gCCodes.nLevel + 1);
				pStr[nIdx+3] = ')';
				nIdx += 4;
				pStr[nIdx] = 0;
			}
		}
	}
	if (nIdx)
		Font8_Print(0, SCR_Height-8, pStr, gVar.pnColors[e_Color_Yellow]);

}

// Level selector si cheat code.
void CheatCodes_LevelSelector(void)
{
	if (gCCodes.nCheat & e_Cheat_LevelSelect)
	{
		if (gVar.pKeys[gMetroCfg.pKeys[e_CfgKey_Right]])
		{
			if (gCCodes.nLevel < LVL_NB-1) gCCodes.nLevel++;
			gVar.pKeys[gMetroCfg.pKeys[e_CfgKey_Right]] = 0;
		}
		if (gVar.pKeys[gMetroCfg.pKeys[e_CfgKey_Left]])
		{
			if (gCCodes.nLevel > 0) gCCodes.nLevel--;
			gVar.pKeys[gMetroCfg.pKeys[e_CfgKey_Left]] = 0;
		}
	}
}

//=============================================================================

void MenuTimer_Reset(void);

// Gestionnaire d'évènements.
int EventHandler(u32 nInGame)
{
	SDL_Event event;

	while (SDL_PollEvent(&event))
	{
		switch (event.type)
		{
		case SDL_KEYDOWN:
			gVar.pKeys[event.key.keysym.sym] = 1;

			// Pas en cours de jeu ?
			if (nInGame == 0)
			{
				CheatCodes_KeyPressed(event.key.keysym.sym);	// Test des cheat codes.
				MenuTimer_Reset();		// RAZ du timer de time out pour les menus.
#ifndef EMERGENCY_EXIT
				if (gVar.pKeys[SDLK_ESCAPE]) return (1);	// Emergency exit.
#endif
			}

// Sortir après la boucle ? => pas sûr.
			// Toggle fullscreen/windowed.
			if (gVar.pKeys[SDLK_F10])
			{
				gRender.nFullscreenMode ^= 1;
				Render_SetVideoMode();
			}
			// Toggle render mode.
			if (gVar.pKeys[SDLK_F9])
			{
				if (++gRender.nRenderMode >= e_RenderMode_MAX) gRender.nRenderMode = 0;
				Render_SetVideoMode();
			}

#ifdef EMERGENCY_EXIT
			if (gVar.pKeys[SDLK_ESCAPE]) return (1);	// Emergency exit.
#endif
			break;

		case SDL_KEYUP:
			gVar.pKeys[event.key.keysym.sym] = 0;
			break;

		case SDL_QUIT:		// Fermeture de la fenêtre.
			exit(0);
			break;
		}
	}

	// Gestion du joystick.
	if (gVar.pJoystick != NULL)
	{
		static u16	pHatMsk[e_CfgKey_LAST] = { SDL_HAT_UP, SDL_HAT_DOWN, SDL_HAT_LEFT, SDL_HAT_RIGHT, 0x100 };
		static u8	pKeyVal[e_CfgKey_LAST] = { e_CfgKey_Up, e_CfgKey_Down, e_CfgKey_Left, e_CfgKey_Right, e_CfgKey_ButtonA };

		u32	i;
		s16	nAxis;
		u16	nHat, nVal;
		nHat = 0;
		// Croix.
		if (gVar.nJoystickNoHat == 0)
			nHat = SDL_JoystickGetHat(gVar.pJoystick, 0);
		// Stick.
		if (gVar.nJoystickNoAxes == 0)
		{
			nAxis = SDL_JoystickGetAxis(gVar.pJoystick, 0);	// X
			if (ABS(nAxis) > 3200) nHat |= (nAxis > 0 ? SDL_HAT_RIGHT : SDL_HAT_LEFT);
			nAxis = SDL_JoystickGetAxis(gVar.pJoystick, 1);	// Y
			if (ABS(nAxis) > 3200) nHat |= (nAxis > 0 ? SDL_HAT_DOWN : SDL_HAT_UP);
		}
		// Boutons.
		if (SDL_JoystickGetButton(gVar.pJoystick, gMetroCfg.pKeys[e_CfgKey_JoyButtonA])) nHat |= 0x100;
//		if (SDL_JoystickGetButton(gVar.pJoystick, gMetroCfg.pKeys[e_CfgKey_JoyButtonB])) nHat |= 0x200;
//		if (SDL_JoystickGetButton(gVar.pJoystick, gMetroCfg.pKeys[e_CfgKey_JoyButtonC])) nHat |= 0x400;

		nVal = gVar.nJoystickState ^ nHat;
		gVar.nJoystickState = nHat;		// Sauvegarde pour le prochain tour.

		for (i = 0; i < e_CfgKey_LAST; i++)
		if (nVal & pHatMsk[i])
		{
			gVar.pKeys[gMetroCfg.pKeys[pKeyVal[i]]] = (nHat & pHatMsk[i] ? 1 : 0);
			gVar.pKeysSDL[gMetroCfg.pKeys[pKeyVal[i]]] = (nHat & pHatMsk[i] ? 1 : 0);
		}

		// Pas en cours de jeu ?
		if (nInGame == 0 && nVal) MenuTimer_Reset();		// RAZ du timer de time out pour les menus.

	}

	return (0);
}

//=============================================================================

// Le Menu (générique).
u32 Menu(void (*pFctInit)(void), u32 (*pFctMain)(void))
{
	u32	nMenuVal = MENU_Null;

	Transit_Init(e_Transit_Off);

	CheatCodes_Reset();

	// Fonction d'init.
	(*pFctInit)();

	gGame.nHiScore = Scr_HighScore_Get();		// Reinit du high-score affiché en cas de cheat. !!! APRES l'init !!!

	// Main loop.
	Frame_Init();
	#if CACHE_ON == 1
	CacheClear();		// RAZ cache.
	#endif
	while (nMenuVal == MENU_Null)
	{
		// Gestion des évenements.
		if (EventHandler(0) != 0) { nMenuVal = MENU_Quit; break; }

		CheatCodes_Counter();
		// Menu, Main fct.
		nMenuVal = (*pFctMain)();
		// Les cheats.
		CheatCodes_LevelSelector();		// Level selector si cheat code.
		CheatCodes_Display();
		// Gestion de la transition.
		Transit_Manage();
		// Wait for frame, Flip.
		Render_Flip(1);
	}

	return (nMenuVal);
}

//=============================================================================

// Game.
void GameLoop(void)
{
	Transit_Init(e_Transit_Off);

	Game_Init();

	// Main loop.
	Frame_Init();

	#if CACHE_ON == 1
	CacheClear();		// RAZ cache.
	#endif
	while (gGame.nExitCode == e_GameEC_Playing)
	{
		// Gestion des évenements.
#ifdef EMERGENCY_EXIT
		if (EventHandler(1)) { gGame.nExitCode = e_GameEC_Aborted; break; }
#else
		EventHandler(1);
#endif
		// Gestion du jeu.
		Game_Manage();
		// Gestion de la transition.
		Transit_Manage();
		// Wait for frame, Flip.
		Render_Flip(1);

	}
	Music_Start(e_YmMusic_NoMusic, 1);

	// Si jeu abandonné, pas de game over, pas de high score, pas de crédits.
	if (gGame.nExitCode == e_GameEC_Aborted) return;

	// All clear ?
	if (gGame.nExitCode == e_GameEC_AllClear)
	{
		Music_Start(e_YmMusic_HighScore, 0);
		Menu(MenuCongratulations_Init, MenuCongratulations_Main);
	}

	// High score ?
	if (gCCodes.nCheat == 0)	// Seulement si pas de cheat code !
	if (gGame.nExitCode == e_GameEC_GameOver || gGame.nExitCode == e_GameEC_AllClear)
	{
		if (Scr_CheckHighSc(gGame.nScore) >= 0)
		{
			Music_Start(e_YmMusic_HighScore, 0);
			Menu(MenuHighScores_Init2, MenuHighScores_Main);
		}
	}
	Music_Start(e_YmMusic_NoMusic, 1);

}

//=============================================================================

// Lecture de tous les sprites.
#define	SLBAR_X	(10)
#define	SLBAR_Y	(206)
#define	SLBAR_W	(300)
#define	SLBAR_H	(12)
void SpritesLoad(void)
{
#if SPR_SAVE == 1

//#include <direct.h>		// _chdir()	// Windows
//#include <unistd.h>		// chdir()	// Linux

	char *pSprFiles[] =
	{
		"gfx/_font_small1.psd",
		"gfx/_spr_hero0.psd",
		"gfx/_spr_objects0.psd",
		"gfx/_testrect.psd",
	};
	u32	i, nNbFiles;
	SDL_Rect	rRct;
	SDL_Surface	*pBkg;

	// Blitte l'image de la disquette à l'écran.
	if ((pBkg = SDL_LoadBMP("gfx/_bkg_disk.bmp")) == NULL)
	{
		fprintf(stderr, "Couldn't load picture 'bkg_disk.bmp': %s\n", SDL_GetError());
		exit(1);
	}
	SDL_BlitSurface(pBkg, NULL, gVar.pScreen, NULL);
	SDL_FreeSurface(pBkg);
	// Préparation des prm fixes de l'indicateur.
	rRct.x = SLBAR_X;
	rRct.y = SLBAR_Y;
	rRct.h = SLBAR_H;

	// Capture.
	nNbFiles = sizeof(pSprFiles)/sizeof(pSprFiles[0]);
	SprInitEngine();
	// Loop.
	for (i = 0; i < nNbFiles; i++)
	{
		// Indicateur de chargement.
		rRct.w = (SLBAR_W * (i + 1)) / nNbFiles;
		SDL_FillRect(gVar.pScreen, &rRct, SDL_MapRGB(gVar.pScreen->format, 255, 0, 0));
		//SDL_Flip(gVar.pScreen);
		Render_Flip(0);

		// Lecture planche de sprites.
		SprLoadGfx(pSprFiles[i]);
	}
	SprBinariesSave();
#else
	SprInitEngine();		// Pour initialiser gnSprSto.
	SprBinariesLoad();
#endif
	SprEndCapture();

}

//=============================================================================

/*
//NDEBUG	// Définir pour supprimer les asserts !
//gcc -DNDEBUG
*/

/*
#ifndef NDEBUG
void Mst00CheckStructSizes(void);
#endif
*/

u32 ChecksumVerify(u32 nLevNo);
u32 ChecksumCalc(u8 *pBuf, u32 nSz);

//#define	EXE_CHECKSUM	(1)		// Commenter la ligne pour virer le test.

#ifdef EXE_CHECKSUM
// Recherche d'une chaîne dans un buffer binaire.
u8 * StrFind(u8 *pToFind, u32 nToFindSz, u8 *pToSearch, u32 nToSearchSz)
{
	if (nToFindSz > nToSearchSz) return (NULL);

	u32	i;
	for (i = 0; i <= nToSearchSz - nToFindSz; i++)
	{
		// On ne compare que le premier char pour commencer.
		if (*pToSearch == *pToFind)
			if (strncmp((char *)pToSearch, (char *)pToFind, nToFindSz) == 0) return (pToSearch);
		pToSearch++;
	}
	return (NULL);
}

// Teste le checksum de l'exe.
void ExeChecksumTst(char *pFilename)
{
	FILE	*fPt = NULL;
	u8	*pBuf = NULL;

	// Ouverture du fichier.
	if ((fPt = fopen(pFilename, "rb")) == NULL)
	{
		fprintf(stderr, "Error opening file '%s'.\n", pFilename);
		goto _err_exit1;
	}
	// Récupération de la taille du fichier.
	s32	nFileSzToLoad, nSz;
	fseek(fPt, 0L, SEEK_END);
	nFileSzToLoad = ftell(fPt);
	fseek(fPt, 0L, SEEK_SET);
//printf("fsize = %d\n", nFileSzToLoad);
	// Malloc du buffer de lecture.
	if ((pBuf = (u8 *)malloc(nFileSzToLoad)) == NULL)
	{
		fprintf(stderr, "malloc failed (pBuf).\n");
		goto _err_exit1;
	}
	// Lecture.
	nSz = fread(pBuf, 1, nFileSzToLoad, fPt);
	if (nSz != nFileSzToLoad)
	{
		fprintf(stderr, "fread error.\n");
		goto _err_exit1;
	}
	fclose(fPt); fPt = NULL;

	// Recherche de la chaîne qui va bien.
	static char	*pStrToFind = "CC\x17\x02****";		// !!! Attention à bien laisser les 4 étoiles pour poke externe du checksum !!!
	u8	*pPtr;

	pPtr = StrFind((u8 *)pStrToFind, 4, pBuf, nFileSzToLoad);
	if (pPtr == NULL)
	{
		fprintf(stderr, "File '%s' has been altered. Aborted.\n", pFilename);
		goto _err_exit1;
	}
//printf("Substring found at offset %X\n", (int)(pPtr - pBuf));
	// Checksum du fichier.
	u32	nSum0 = *(u32 *)(pPtr + 4);
	// On efface les 4 cases du checksum.
	memset(pPtr + 4, 0, 4);
	// Recalcul du Checksum.
	u32	nSum1 = ChecksumCalc(pBuf, nFileSzToLoad);
//printf("Exe checksum = %X\n", nSum1);
	free(pBuf); pBuf = NULL;

	// Ok ?
	if (nSum0 != nSum1)
	{
		fprintf(stderr, "File '%s' has been altered. Aborted.\n", pFilename);
		exit(1);
	}
	return;

_err_exit1:
	if (fPt != NULL) fclose(fPt);
	if (pBuf != NULL) free(pBuf);
	exit (1);

}
#endif

//=============================================================================

// Recherche d'un éventuel flag 'nogl' sur la ligne de commande.
void CmdLine_Search(int argc, char **argv)
{
	u32	i = 1;			// On saute le nom de l'exe.
	while (i < argc)
	{
		char	*pPrm = argv[i++];
//		printf("%s\n", pPrm);
		if (*pPrm == '-' || *pPrm == '/') pPrm++;
		if (stricmp(pPrm, "nogl") == 0)
		{
//			printf("nogl found!\n");
			gRender.nUseGL = 0;
			return;
		}
	}
}

//=============================================================================

// Point d'entrée.
int main(int argc, char **argv)
{
	u32	nLoop;
	u32	nMenuVal;

	gRender.nUseGL = 1;
	CmdLine_Search(argc, argv);		// Cherche pour 'nogl' dans les arguments.

/*
#ifndef NDEBUG
	// Debug : Vérifie la taille des structures spécifiques des monstres.
	Mst00CheckStructSizes();
#endif
*/

#ifdef EXE_CHECKSUM
	// Test d'intégrité sur l'exe.
	ExeChecksumTst(argv[0]);
#endif

	// Test d'intégrité sur les fichiers EDT.
	u32	i;
	for (i = 1; i <= LVL_NB; i++)
		ChecksumVerify(i);

	// SDL Init.
	if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_JOYSTICK) < 0)
	{
		fprintf(stderr, "Unable to init SDL: %s\n", SDL_GetError());
		exit(1);
	}
	// atexit : Quand on quittera (exit, return...), SDL_Quit() sera appelée.
	atexit(SDL_Quit);

	const SDL_VideoInfo *pVideoInfo = SDL_GetVideoInfo();
#if defined(RENDER_BPP)
	gRender.nRenderBPP = (pVideoInfo->vfmt->BitsPerPixel > 16 ? 1 : 0);
//printf("bits pp = %d / v=%d\n", pVideoInfo->vfmt->BitsPerPixel, gRender.nRenderBPP);
//printf("bytes pp = %d\n", pVideoInfo->vfmt->BytesPerPixel);
#endif
	int	nOrgW, nOrgH, nOrgBitsPerPixel;
	nOrgW = pVideoInfo->current_w;
	nOrgH = pVideoInfo->current_h;
	nOrgBitsPerPixel = pVideoInfo->vfmt->BitsPerPixel;
//fprintf(stderr, "Original resolution: %d x %d - %d BPP\n", nOrgW, nOrgH, nOrgBitsPerPixel);

	// Video mode init.
	Render_InitVideo();
	SDL_WM_SetCaption("Metro-Cross by 17o2!!", NULL);	// Nom de la fenêtre.

	// Lecture du fichier de conf.
	Cfg_Load();
	// Passe dans le mode video de la conf.
	if (gMetroCfg.nVideoMode != gRender.nRenderMode)
	{
		gRender.nRenderMode = gMetroCfg.nVideoMode;
		Render_SetVideoMode();
	}

	// Init joystick.
	gVar.pJoystick = NULL;
	gVar.nJoystickState = 0;
	if (SDL_NumJoysticks() > 0)
	{
		SDL_JoystickEventState(SDL_ENABLE);
		gVar.pJoystick = SDL_JoystickOpen(0);		// Si pas NULL, joystick !
		if (gVar.pJoystick != NULL)
		{
			u32	nJoystickNumButtons = SDL_JoystickNumButtons(gVar.pJoystick);
			gVar.nJoystickNoHat = (SDL_JoystickNumHats(gVar.pJoystick) < 1 ? 1 : 0);
			gVar.nJoystickNoAxes = (SDL_JoystickNumAxes(gVar.pJoystick) < 2 ? 1 : 0);

			// Config boutons ok ?
			if (gMetroCfg.pKeys[e_CfgKey_JoyButtonA] >= nJoystickNumButtons)// ||
				//gMetroCfg.pKeys[e_CfgKey_JoyButtonB] >= nJoystickNumButtons ||
				//gMetroCfg.pKeys[e_CfgKey_JoyButtonC] >= nJoystickNumButtons)
			{
				fprintf(stderr, "Joystick configuration can't be used with this joystick.\nPlease run the configuration program.\n");
				goto _JoyOff;
			}
			// Hardware ok ?
			if (nJoystickNumButtons < 3 || (gVar.nJoystickNoHat && gVar.nJoystickNoAxes))
			{
				// Pas assez de boutons ? => Disable.
				fprintf(stderr, "Unable to handle joystick.\n");
_JoyOff:
				fprintf(stderr, "Joystick disabled.\n");
				SDL_JoystickClose(gVar.pJoystick);
				gVar.pJoystick = NULL;
			}
		}
	}

	gnFrame = 0;	// RAZ compteur de frames.
	// Init du clavier.
	gVar.pKeysSDL = SDL_GetKeyState(NULL);
	memset(gVar.pKeys, 0, SDLK_LAST);
	// Allocation des buffers de scroll.
	Scroll_Allocate();
	// Lecture des graphs de décor (communs à tous les niveaux).
	Loader_BlocksLoad("gfx/gnd0.psd", &gGfxBlk.pBlocks);
	Loader_BlocksLoad("gfx/bkg0.psd", &gGfxBlk.pBackground);
	// Logo.
	Loader_BlocksLoad("gfx/mclogo.psd", &gVar.pImgLogo);
	SDL_SetColorKey(gVar.pImgLogo, SDL_SRCCOLORKEY, 0);
	// Image pour rotozoom. (Load à part car il ne faut pas faire le convert surface !).
	char	*pImgRotoFilename = "gfx/img_roto.psd";
	gVar.pImgRoto = PSDLoadToSDLSurf(pImgRotoFilename);
	if (gVar.pImgRoto == NULL)
	{
		fprintf(stderr, "Couldn't load picture '%s': %s\n", pImgRotoFilename, SDL_GetError());
		exit(1);
	}

	// Preca Sinus et Cosinus.
	PrecaSinCos();

	SDL_ShowCursor(SDL_DISABLE);	// Cache le pointeur de la souris.

	// Load sprites.
	SpritesLoad();

	// Load levels.
	Loader_LevelsLoad();

	// Init sound.
	Sfx_SoundInit();
	Sfx_LoadWavFiles();
	Sfx_LoadYMFiles();
	Sfx_SoundOn();	// Starts playback.

	// Misc inits.
	Transit_Init(e_Transit_Off);
	gCCodes.nCheat = 0;		// RAZ cheat codes.
	gCCodes.nLevel = 0;

	Scr_Load();				// Lecture de la table des high-scores.
	gGame.nScore = 0;
	gGame.nHiScore = Scr_HighScore_Get();

	RotoZoom_Init();

	// Boucle infinie.
	nMenuVal = MENU_Main;
	nLoop = 1;
	while (nLoop)
	{
		switch (nMenuVal)
		{
		case MENU_Main:		// Main menu.
			nMenuVal = Menu(MenuMain_Init, MenuMain_Main);

/*
*/
// test hi score
if (nMenuVal != MENU_Main && nMenuVal != MENU_Quit)
{
nMenuVal = MENU_HallOfFame;
}
			break;

		case MENU_Game:		// Jeu.
			GameLoop();
			nMenuVal = MENU_Main;
			break;

		case MENU_HallOfFame:	// High scores.
/*
*/
// test hi score
{
static	u32	nSc = 70000;
gGame.nScore = nSc;

if (Scr_CheckHighSc(gGame.nScore) >= 0)
{
//	Music_Start(e_YmMusic_HighScore, 0);
	Menu(MenuHighScores_Init2, MenuHighScores_Main);
}
//Music_Start(e_YmMusic_NoMusic, 1);
nSc += 5000;

}
nMenuVal = MENU_Main;
break;

			Menu(MenuHighScores_Init, MenuHighScores_Main);
			nMenuVal = MENU_Main;
			break;

		case MENU_Quit:		// Sortie.
			nLoop = 0;
			break;
		}

	}

	SDL_ShowCursor(SDL_ENABLE);		// Réautorise l'affichage du curseur de la souris.

	if (gVar.pJoystick != NULL) SDL_JoystickClose(gVar.pJoystick);

	Sfx_SoundOff();	// Stops playback.
	Sfx_FreeWavFiles();	// Libère les ressources des Fx.
	Sfx_FreeYMFiles();	// Libère les ressources des YMs.

	// Libère les niveaux.
	Loader_LevelsRelease();

	// Libère les ressources des sprites.
	SprRelease();
	// Libère les buffers de scroll.
	Scroll_Release();
	// Libère les graphs de décor.
	Loader_BlocksRelease(&gGfxBlk.pBlocks);
	Loader_BlocksRelease(&gGfxBlk.pBackground);

	Loader_BlocksRelease(&gVar.pImgLogo);
	SDL_FreeSurface(gVar.pImgRoto);

	// Libère les ressources de rendu.
	Render_Release();


#if defined(__LINUX__)
if (gRender.nUseGL)
{
fprintf(stderr, "***\nTo Linux users:\n\
Please enter the following command if the resolution is messed up:\n\
xrandr -s %dx%d\n", nOrgW, nOrgH);
}
#endif


	SDL_Quit();
	return (0);
}



